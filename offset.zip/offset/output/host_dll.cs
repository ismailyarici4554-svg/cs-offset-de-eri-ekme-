// Generated using https://github.com/a2x/cs2-dumper
// 2026-11-20 17:47:42.266886200 UTC

namespace CS2Dumper.Schemas {
    // Module: host.dll
    // Class count: 2
    // Enum count: 0
    public static class HostDll {
        // Parent: None
        // Field count: 1
        public static class EmptyTestScript {
            public const nint m_hTest = 0x10; // CAnimScriptParam<float32>
        }
        // Parent: None
        // Field count: 1
        public static class CAnimScriptBase {
            public const nint m_bIsValid = 0x8; // bool
        }
    }
}
