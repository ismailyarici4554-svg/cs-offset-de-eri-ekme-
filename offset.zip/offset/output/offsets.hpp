// Generated using https://github.com/a2x/cs2-dumper
// 2026-11-20 17:47:42.266886200 UTC

#pragma once

#include <cstddef>
#include <cstdint>

namespace cs2_dumper {
    namespace offsets {
        // Module: client.dll
        namespace client_dll {
            constexpr std::ptrdiff_t dwCSGOInput = 0x256D560;
            constexpr std::ptrdiff_t dwEntityList = 0x270D5B0;
            constexpr std::ptrdiff_t dwGameEntitySystem = 0x270D5B0;
            constexpr std::ptrdiff_t dwGameEntitySystem_highestEntityIndex = 0x2120;
            constexpr std::ptrdiff_t dwGameRules = 0x25573F8;
            constexpr std::ptrdiff_t dwGlobalVars = 0x2223AD0;
            constexpr std::ptrdiff_t dwGlowManager = 0x2554110;
            constexpr std::ptrdiff_t dwLocalPlayerController = 0x252F300;
            constexpr std::ptrdiff_t dwLocalPlayerPawn = 0x2557AB8;
            constexpr std::ptrdiff_t dwPrediction = 0x25579C0;
            constexpr std::ptrdiff_t dwViewAngles = 0x256DBE8;
            constexpr std::ptrdiff_t dwViewMatrix = 0x255D3D0;
            constexpr std::ptrdiff_t dwViewRender = 0x255DD98;
            constexpr std::ptrdiff_t dwWeaponC4 = 0x24BBC00;
        }
        // Module: engine2.dll
        namespace engine2_dll {
            constexpr std::ptrdiff_t dwBuildNumber = 0x6B2D1C;
            constexpr std::ptrdiff_t dwNetworkGameClient = 0x9AFB90;
            constexpr std::ptrdiff_t dwNetworkGameClient_clientTickCount = 0x398;
            constexpr std::ptrdiff_t dwNetworkGameClient_deltaTick = 0x24C;
            constexpr std::ptrdiff_t dwNetworkGameClient_isBackgroundMap = 0x2C143F;
            constexpr std::ptrdiff_t dwNetworkGameClient_localPlayer = 0xF8;
            constexpr std::ptrdiff_t dwNetworkGameClient_maxClients = 0x240;
            constexpr std::ptrdiff_t dwNetworkGameClient_serverTickCount = 0x24C;
            constexpr std::ptrdiff_t dwNetworkGameClient_signOnState = 0x230;
            constexpr std::ptrdiff_t dwWindowHeight = 0x9B42EC;
            constexpr std::ptrdiff_t dwWindowWidth = 0x9B42E8;
        }
        // Module: inputsystem.dll
        namespace inputsystem_dll {
            constexpr std::ptrdiff_t dwInputSystem = 0x46BC0;
        }
        // Module: matchmaking.dll
        namespace matchmaking_dll {
            constexpr std::ptrdiff_t dwGameTypes = 0x1AEFC0;
        }
        // Module: soundsystem.dll
        namespace soundsystem_dll {
            constexpr std::ptrdiff_t dwSoundSystem = 0x532470;
        }
    }
}
